<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//registrasi pengguna
Route::post('/register', 'Auth\RegisterController@register')->name('register');

//LOGIN PENGGUNA
Route::post('/login', 'Auth\LoginController@login')->name('login');

//PILIH JUZ
Route::get('/juz', 'JuzController@index')->name('juz.index');

//BACA AL-QURAN
Route::get('/quran', 'QuranController@index')->name('quran.index');

//TANDAI HAFALAN
Route::post('/hafalan', 'HafalanController@store')->name('hafalan.store');

//MONITOR KEMAJUAN
Route::get('/progress', 'ProgressController@index')->name('progress.index');

// routes/web.php

use App\Http\Controllers\JuzController;
use App\Http\Controllers\QuranController;
use App\Http\Controllers\HafalanController;
use App\Http\Controllers\ProgressController;

// Rute untuk halaman Juz
Route::get('/juz', [JuzController::class, 'index'])->name('juz');

// Rute untuk halaman Al-Qur'an
Route::get('/quran', [QuranController::class, 'index'])->name('quran');

// Rute untuk halaman Hafalan
Route::get('/hafalan', [HafalanController::class, 'index'])->name('hafalan');

// Rute untuk halaman Kemajuan
Route::get('/progress', [ProgressController::class, 'index'])->name('progress');
